/**
 * 
 */
/**
 * @author badraelmi
 *
 */
module SolitaireGame {
	requires java.desktop;
}